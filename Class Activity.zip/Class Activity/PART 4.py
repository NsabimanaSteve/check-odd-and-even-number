def sum_of_square(xs):
    total = 0
    for num in xs:
        total =total + num**2
    return total
xs=[2,3,4]
result = sum_of_square(xs)
print(sum_of_square(xs))
