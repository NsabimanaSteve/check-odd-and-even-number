# Start with an empty list
myList = []

# Use append to add the first item (76)
myList.append(76)

# Use append to add the second item (92.3)
myList.append(92.3)

# Use append to add the third item ("hello")
myList.append("hello")

# Use concatenation to add the fourth item (True)
myList = myList+ [True]

# Use concatenation to add the fifth item (4)
myList = myList + [4]

# Use concatenation to add the sixth item (76)
myList = myList + [76]
print(myList)
